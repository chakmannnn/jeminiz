// React not used — index.html is a standalone HTML/CSS/JS page
import "./index.css";
